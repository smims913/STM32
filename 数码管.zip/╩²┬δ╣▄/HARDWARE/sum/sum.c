#include "led.h"
#include "sum.h"

void num0()
{
	LED0=0;
	LED1=0;
	LED2=0;
	LED3=0;
	LED4=0;
	LED5=1;
	LED6=0;
}
void num1()
{
	LED0=1;
	LED1=0;
	LED2=0;
	LED3=1;
	LED4=1;
	LED5=1;
	LED6=1;
}
void num2()
{
	LED0=0;
	LED1=0;
	LED2=1;
	LED3=0;
	LED4=0;
	LED5=0;
	LED6=1;
}
void num3()
{
	LED0=0;
	LED1=0;
	LED2=0;
	LED3=0;
	LED4=1;
	LED5=0;
	LED6=1;
}
void num4()
{
	LED0=1;
	LED1=0;
	LED2=0;
	LED3=1;
	LED4=1;
	LED5=0;
	LED6=0;
}
void num5()
{
	LED0=0;
	LED1=1;
	LED2=0;
	LED3=0;
	LED4=1;
	LED5=0;
	LED6=0;
}
void num6()
{
	LED0=0;
	LED1=1;
	LED2=0;
	LED3=0;
	LED4=0;
	LED5=0;
	LED6=0;
}
void num7()
{
	LED0=0;
	LED1=0;
	LED2=0;
	LED3=1;
	LED4=1;
	LED5=1;
	LED6=1;
}
void num8()
{
	LED0=0;
	LED1=0;
	LED2=0;
	LED3=0;
	LED4=0;
	LED5=0;
	LED6=0;
}
void num9()
{
	LED0=0;
	LED1=0;
	LED2=0;
	LED3=0;
	LED4=1;
	LED5=0;
	LED6=0;
}

