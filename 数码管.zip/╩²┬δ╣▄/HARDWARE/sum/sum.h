#ifndef __SUM_H
#define __SUM_H
#include "sys.h"

void num0(void);
void num1(void);
void num2(void);
void num3(void);
void num4(void);
void num5(void);
void num6(void);
void num7(void);
void num8(void);
void num9(void);

#endif
