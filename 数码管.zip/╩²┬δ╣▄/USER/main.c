#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"

int main(void)
{ 
	delay_init(168);		  //��ʼ����ʱ����
	LED_Init();		        //��ʼ��LED�˿�
  while(1)
	{
		num0();
		delay_ms(500);
		num1();
		delay_ms(500);
		num2();
		delay_ms(500);
		num3();
		delay_ms(500);
		num4();
		delay_ms(500);
		num5();
		delay_ms(500);	
		num6();
		delay_ms(500);	
		num7();
		delay_ms(500);			
		num8();
		delay_ms(500);
		num9();
		delay_ms(500);		
	 }
}
